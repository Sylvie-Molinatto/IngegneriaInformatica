REMARK
/*
Definizione di un indice "sal_Ind" sul campo "sal" nella tabella emp  
*/

CREATE INDEX sal_ind on EMP(sal);
